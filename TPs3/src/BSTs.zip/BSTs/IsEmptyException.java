package BSTs;

public class IsEmptyException extends Exception {
    public IsEmptyException(){
        super();
    }
}
